﻿Console.Write("Inserisci un numero: ");
int n=int.Parse(Console.ReadLine());
int somma = 1,i=0;
string msg="";
int sommaFinale = 1;
for (i=1; i<n; i++)
{
    //Console.Write(somma);
    somma += 2;
    msg += "+"+somma ;
    sommaFinale += somma;

}

Console.WriteLine(sommaFinale+" = 1"+msg);
