﻿/*
 visualizzare 100 numeri pari positivi
 */
for(int i = 0;i<100;i++)
    Console.WriteLine(i*2);