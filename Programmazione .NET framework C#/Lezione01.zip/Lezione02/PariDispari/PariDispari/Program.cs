﻿/*
 Dato in input un numero intero,
 stabilire se pari o dispari

 Visualizzare il risultato
 */
Console.Write("Inserisci un numero intero: ");
int n = int.Parse(Console.ReadLine());
if (n%2== 0)
    Console.WriteLine($"{n} e' pari");
else
    Console.WriteLine($"{n} e' dispari");
