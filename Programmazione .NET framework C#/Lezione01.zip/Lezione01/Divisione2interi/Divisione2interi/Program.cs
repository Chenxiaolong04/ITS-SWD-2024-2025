﻿/*
Dati in input 2 numeri interi 
calcolare in quoziente intero, il resto e il quoziente reale 
Visualizza i risultati
*/
Console.Write("Dividendo: ");
int a = int.Parse(Console.ReadLine());
Console.Write("Divisore: ");
int b = int.Parse(Console.ReadLine());
//Calcoli
int qi = a / b;
int r = a % b;
double qr = (double)a / b;
Console.WriteLine("{0}/{1}", a, b);
Console.WriteLine("Quoziente intero: {0}", qi);
Console.WriteLine("Resto: {0}", r);
Console.WriteLine("Quoziente reale: {0}", qr);
