﻿/*
 * Prezzo: 10,00
 * Quantita: 3
 * Percentuale di sconto: 30
 * 
 * Totale: 30,00 euro
 * Sconto effettualo: 9 euro
 * Totale scontato: 21,00 euro
 */

Console.Write("Prezzo: ");
double prezzo = double.Parse(Console.ReadLine());
Console.Write("Quantità: ");
int quantita = int.Parse(Console.ReadLine());
Console.Write("Percentuale di sconto: ");
int percentualeSconto = int.Parse(Console.ReadLine());
double totale = prezzo * quantita;
double sconto=totale * percentualeSconto/100;
double totaleScontato=totale-sconto;
Console.WriteLine("\nTotale: {0} euro", totale);
Console.WriteLine("Sconto effettuato: {0} euro", sconto);
Console.WriteLine("Totale scontato: {0} euro", totaleScontato);