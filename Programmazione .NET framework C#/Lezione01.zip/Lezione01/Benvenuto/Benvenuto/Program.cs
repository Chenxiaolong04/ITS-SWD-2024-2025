﻿// See https://aka.ms/new-console-template for more information
Console.Write("Benvenuto nel mio primo programma C#");
