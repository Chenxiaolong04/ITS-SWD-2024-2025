﻿/*
 Dato in input l'imponibile,
 calcolare il totale da pagare
 sapendo che l'aliquota iva è al 22%
 Visualizzare i risultati

 Esempio:
 Imponibile: 156,99 euro

 Iva (22%): ?? euro

 Totale: ?? euro
 */
Console.Write("Imponibile: ");
double imponibile= double.Parse(Console.ReadLine());
//calcoli
int aliquotaIva = 22;
double Iva = imponibile*aliquotaIva/100;
double totale=imponibile+Iva;
//usare il format - stampa dettaglio
string msg=$"\n\nImponibile: {imponibile} euro"+
    $"\nIva({aliquotaIva}%):{Iva:#.##} euro"+
    $"\nTotale: {totale:#.##} euro";
Console.Write(msg);