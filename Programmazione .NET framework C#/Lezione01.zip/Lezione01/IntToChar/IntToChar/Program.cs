﻿// Dato in input un numero intero [32,127] 
// Visualizzare il carattere corrispondente in ASCII standart
Console.Write("Inserisci un numero intero da tastiera[32,127]: ");
int posizione = int.Parse(Console.ReadLine());
char c = (char)posizione;
Console.WriteLine("La posizione ASCII {0} corrisponde al carattere: {1}", posizione, c);