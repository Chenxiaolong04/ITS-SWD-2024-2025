﻿namespace ClasseQuadrato
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Uso di oggetti di tipo quadrato");
            //oggetto
            Quadrato q;
            //istanza
            q = new Quadrato();
            q.lato = 1.55;//scrittura
            Console.WriteLine($"Lato: {q.lato}");
            Console.WriteLine($"Perimetro: {q.Perimetro()}");
            Console.WriteLine($"Area: {q.Area()}");
            Console.WriteLine($"Diagonale: {q.Diagonale()}");
        }
    }
}
