﻿/*
Creare un array di nomi di persone 
Visualizzare tutti i nomi 
 */
Console.WriteLine("Array di nomi di persona!");
//definizione dell'array

string[] nomi = new string[] {
            "Alice", "Marco", "Giulia", "Luca", "Francesca", "Davide", "Sara", "Matteo", "Elena", "Giorgio",
            "Andrea", "Valentina", "Stefano", "Chiara", "Fabio", "Martina", "Simone", "Laura", "Alessandro", "Claudia",
            "Riccardo", "Silvia", "Emanuele", "Beatrice", "Antonio", "Veronica", "Federico", "Eleonora", "Giovanni", "Serena",
            "Daniele", "Miriam", "Pietro", "Roberta", "Nicola", "Anna", "Tommaso", "Irene", "Vincenzo", "Camilla",
            "Gabriele", "Vanessa", "Christian", "Debora", "Samuel", "Marta", "Massimo", "Aurora", "Edoardo", "Sofia"
};
var i = 0;
foreach (string nome in nomi)
{
    Console.WriteLine($"{i++} {nome.ToUpper()}");
}