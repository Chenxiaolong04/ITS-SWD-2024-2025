﻿/*
 Dato un array di numeri interi,
 di dimensione 5
 riempirlo
 visualizzare posizione e valore
 */
Console.WriteLine("Array di numeri interi");
int[] numeri = new int[5];
// scrittura su array
numeri[0] = 12;
numeri[1] = -11;
numeri[2] = -3;
numeri[3] = -4;
numeri[4] = 5;
//lettura
Console.WriteLine($"Posizione: 3 - valore: {numeri[3]}");
//lettura di tutto l'array
Console.WriteLine("Stampa array con ciclo for");
for( int i = 0; i < numeri.Length; i++)
{
    Console.WriteLine($"Posizione {i} valore: {numeri[i]}");
}
//foreach
Console.WriteLine("Stampa array con foreach");
foreach (var numero in numeri)
{
    Console.WriteLine($"Posizione {numero} valore: {numero}");
}
