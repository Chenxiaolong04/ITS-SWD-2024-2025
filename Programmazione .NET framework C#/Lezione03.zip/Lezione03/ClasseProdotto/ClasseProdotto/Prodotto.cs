﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasseProdotto
{
    internal class Prodotto
    {
        //string? indica che puo non esserci il valore

        //attributi
        private int codice;
        public int Codice
        {
            get { return codice; }
            set { codice = value; }
        }
        private double prezzo;

        public double Prezzo
        {
            get { return prezzo; }
            set { prezzo = value; }
        }

        private int giacenza;

        public int Giacenza
        {
            get { return giacenza; }
            set { giacenza = value; }
        }


        //metodi

        private string denominazione;

        public string Denominazione
        {
            get { return denominazione; }
            set { denominazione = value; }
        }

        //Prodotto in scorta se la sua giacenza [1,9]
        public bool IsInScorta()
        {
            return giacenza >= 1 && giacenza <= 9;
        }
        //Prodotto esaurito se la sua giacenza è 0
        public bool IsEsaurito()
        {
            return giacenza == 0;
        }
        //metodo "Consumer"
        public string StampaDettaglio()
        {
            return $"Codice: {codice}" +
                $"\nDenominazione: {denominazione}" +
                $"\nPrezzo: {prezzo}" +
                $"\nGiacenza: {giacenza}";
        }
        public string StampaLineare()
        {
            return $"Codice: {codice}," +
                $" Denominazione: {denominazione}," +
                $" Prezzo: {prezzo}," +
                $" Giacenza: {giacenza}";
        }
    }
}
