﻿/*
 Visualizzare 100 numeri interi positivi

 */

for (int i = 0; i < 100; i++)
    Console.WriteLine(i);