﻿/*
dato in input un numero intero (1,7)
visualizzare il nome del relativo giorno della settimana
es. 2 = martedi
es. 9 = errore
 */
Console.Write("Numero (1,7): ");
int n = int.Parse(Console.ReadLine());
switch (n)
{
    case 1:
        Console.WriteLine("Lunedi");
        break;
    case 2: Console.WriteLine("Martedi");
        break;
    case 3: Console.WriteLine("Mercoledi");
        break;
    case 4:
        Console.WriteLine("Giovedi");
        break;
    case 5:
        Console.WriteLine("Venerdi");
        break;
    case 6:
        Console.WriteLine("Sabato");
        break;
    case 7:
        Console.WriteLine("Domenica");
        break;
    default:
        Console.WriteLine("Errore");
        break;
}

