﻿/*
 Dato in input il lato del quadrato
 calcolare diametro, circonferenza e area
 visualizza i risultati
 */
Console.Write("Inserisci raggio: ");
double raggio = double.Parse(Console.ReadLine());
//calcoli
double diametro = raggio*2;
double area = raggio * raggio * Math.PI;
double circonferenza = 2 * Math.PI * raggio;
//output
//stampa dettaglio
String msg = $"Diametro: {diametro}"+
    $"\nCirconferenza: {circonferenza}"+
    $"\nArea: {area}";

Console.WriteLine(msg);