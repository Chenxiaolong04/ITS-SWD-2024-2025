﻿/*
 dati i lati di un triangolo
 calcolare perimetro, area
 */