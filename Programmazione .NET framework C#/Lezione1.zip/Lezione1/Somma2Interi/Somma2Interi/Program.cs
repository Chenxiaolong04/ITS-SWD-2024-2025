﻿// Dati in input 2 numeri iinteri calcolare la somma
// Calcolare la somma
// Visualizzare la somma

//input
Console.Write("Inserisci un numero intero: ");
string tmp=Console.ReadLine();
int a=int.Parse(tmp);

Console.Write("Inserisci un altro numero intero: ");
int b = int.Parse(Console.ReadLine());
//calcolo
int somma = a + b;
//output
Console.WriteLine(somma);
