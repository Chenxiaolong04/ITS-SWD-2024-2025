﻿// Dato in input un carattere rappresentabile
// Visualizza la sua posizione in ASCII standart
Console.Write("Inserisci un carattere da tastiera: ");
char c= char.Parse(Console.ReadLine());
int posizione=(int)c;
Console.WriteLine("Il carattere {0} e' in posizione ASCII: {1}",c,posizione);