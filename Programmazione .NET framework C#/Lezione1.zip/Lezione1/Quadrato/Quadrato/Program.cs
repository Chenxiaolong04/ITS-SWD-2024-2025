﻿/*
 Dato in input il lato del quadrato
 calcolare perimetro area e diagonale
 visualizza i risultati
 */
Console.Write("Inserisci lato piastrella: ");
double lato = double.Parse(Console.ReadLine());
//area
double area = lato * lato;
//perimetro
double perimetro = lato * 4;
//diagonale
double diagonale = lato * Math.Sqrt(2);
//output
Console.WriteLine("Perimetro: " + perimetro);
Console.WriteLine("Area: {0}", area);
Console.WriteLine($"Diagonale: {diagonale}");//interpolazione