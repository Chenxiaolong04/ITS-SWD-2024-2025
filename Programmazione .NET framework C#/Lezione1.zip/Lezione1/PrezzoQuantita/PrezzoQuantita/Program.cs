﻿/*
 * Prezzo = 10.25
 * quantita: 3
 * Totale: 30.75
 */
Console.Write("Prezzo: ");
double prezzo = double.Parse(Console.ReadLine());
Console.Write("Quantità: ");
int quantita = int.Parse(Console.ReadLine());
double totale=prezzo*quantita;
Console.WriteLine("Totale: {0} euro",totale);