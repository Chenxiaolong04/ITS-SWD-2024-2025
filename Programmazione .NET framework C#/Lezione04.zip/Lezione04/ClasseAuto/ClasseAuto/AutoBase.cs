﻿namespace ClasseAuto
{
    internal class AutoBase
    {

        private string modello;
    }
}