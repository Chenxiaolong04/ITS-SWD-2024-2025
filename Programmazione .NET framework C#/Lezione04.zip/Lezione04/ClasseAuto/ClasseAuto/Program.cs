﻿namespace ClasseAuto
{
    class Auto
    {
        // Attributi
        private string marca;
        private string modello;
        private int cilindrata;
        private string alimentazione;
        private string colore;

        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }

        public string Modello
        {
            get { return modello; }
            set { modello = value; }
        }

        public int Cilindrata
        {
            get { return cilindrata; }
            set { cilindrata = value; }
        }

        public string Alimentazione
        {
            get { return alimentazione; }
            set { alimentazione = value; }
        }

        public string Colore
        {
            get { return colore; }
            set { colore = value; }
        }
        public int calcoloVelocitaMax()
        {
            int velocitaBase=cilindrata/10;

            switch (alimentazione) {
                case "benzina":
                    velocitaBase += 30;
                    break;
                case "diesel":
                    velocitaBase += 20;
                    break;
                case "gpl":
                    velocitaBase -= 10;
                    break;
                case "metano":
                    velocitaBase -= 30;
                    break;
            }
            return velocitaBase;

        }
        public void Stampa()
        {
            Console.WriteLine($"Marca: {Marca}");
            Console.WriteLine($"Modello: {Modello}");
            Console.WriteLine($"Cilindrata: {Cilindrata}");
            Console.WriteLine($"Alimentazione: {Alimentazione}");
            Console.WriteLine($"Colore: {Colore}");
            Console.WriteLine($"Velocità Max: {calcoloVelocitaMax()} km/h\n");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            //auto 1
            Auto auto1 = new Auto();
            auto1.Marca = "Fiat";
            auto1.Modello = "Panda";
            auto1.Cilindrata = 1200;
            auto1.Alimentazione = "benzina";
            auto1.Colore = "bianco";
            auto1.Stampa();
            //auto 2
            Auto auto2 = new Auto();
            auto2.Marca = "Volkswagen";
            auto2.Modello = "Golf";
            auto2.Cilindrata = 1600;
            auto2.Alimentazione = "diesel";
            auto2.Colore = "nero";
            auto2.Stampa();
            //auto 3
            Auto auto3 = new Auto();
            auto3.Marca = "Opel";
            auto3.Modello = "Corsa";
            auto3.Cilindrata = 1000;
            auto3.Alimentazione = "gpl";
            auto3.Colore = "rosso";
            auto3.Stampa();
        }
    }
}
