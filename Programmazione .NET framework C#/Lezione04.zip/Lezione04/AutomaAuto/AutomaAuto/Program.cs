﻿using System;

namespace ClasseAuto
{
    class Auto
    {
        // Attributi
        private string marca;
        private string modello;
        private int cilindrata;
        private string alimentazione;
        private string colore;

        private int velocitaBase;
        private int velocitaAttuale = 50;

        // Proprietà
        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }

        public string Modello
        {
            get { return modello; }
            set { modello = value; }
        }

        public int Cilindrata
        {
            get { return cilindrata; }
            set { cilindrata = value; }
        }

        public string Alimentazione
        {
            get { return alimentazione; }
            set { alimentazione = value.ToLower(); }
        }

        public string Colore
        {
            get { return colore; }
            set { colore = value; }
        }

        // Calcolo della velocità massima
        public int CalcoloVelocitaMax()
        {
            velocitaBase = cilindrata / 10;

            switch (alimentazione)
            {
                case "benzina":
                    velocitaBase += 30;
                    break;
                case "diesel":
                    velocitaBase += 20;
                    break;
                case "gpl":
                    velocitaBase -= 10;
                    break;
                case "metano":
                    velocitaBase -= 30;
                    break;
            }

            return velocitaBase;
        }

        public void Stampa()
        {
            Console.WriteLine($"Marca: {Marca}, Modello: {Modello}, Cilindrata: {Cilindrata}, Alimentazione: {Alimentazione}, Colore: {Colore}, Velocità Max: {CalcoloVelocitaMax()} km/h");
        }

        // Metodo per visualizzare la velocità attuale
        public void MostraVelocitaAttuale()
        {
            Console.WriteLine($"Velocità attuale: {velocitaAttuale} km/h");
            if (velocitaAttuale > 130)
            {
                Console.WriteLine("Rallenta! Stai andando troppo forte!");
            }
        }

        public void Accelera()
        {
            velocitaAttuale += 10;
            if (velocitaAttuale>velocitaBase)
                velocitaAttuale=velocitaBase;
            MostraVelocitaAttuale();
        }

        public void Frena()
        {
            velocitaAttuale -= 5;
            if (velocitaAttuale < 0)
                velocitaAttuale = 0;

            MostraVelocitaAttuale();
        }
    }

    // Programma principale
    internal class Program
    {
        static void Main(string[] args)
        {
            Auto auto1 = new Auto();
            auto1.Marca = "Fiat";
            auto1.Modello = "Panda";
            auto1.Cilindrata = 1200;
            auto1.Alimentazione = "benzina";
            auto1.Colore = "bianco";
            auto1.Stampa();

            while (true)
            {
                Console.WriteLine("\nScegli un'azione:");
                Console.WriteLine("1 - Accelera");
                Console.WriteLine("2 - Frena");
                Console.WriteLine("0 - Esci");
                Console.Write("Scelta: ");

                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        auto1.Accelera();
                        break;
                    case "2":
                        auto1.Frena();
                        break;
                    case "0":
                        Console.WriteLine("Uscita dal programma.");
                        return;
                    default:
                        Console.WriteLine("Scelta non valida.");
                        break;
                }
            }
        }
    }
}
