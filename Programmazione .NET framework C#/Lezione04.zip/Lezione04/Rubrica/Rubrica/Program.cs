﻿using System;

namespace Rubrica
{
    class Indirizzo
    {
        public string Via { get; set; }
        public string Cap { get; set; }
        public string Citta { get; set; }
        public string Provincia { get; set; }

        // Costruttore completo
        public Indirizzo(string via, string cap, string citta, string provincia)
        {
            Via = via;
            Cap = cap;
            Citta = citta;
            Provincia = provincia;
        }

        // Costruttore con valori di default
        public Indirizzo()
        {
            Via = "X";
            Cap = "X";
            Citta = "X";
            Provincia = "X";
        }

        public override string ToString()
        {
            return $"Via {Via} {Cap} {Citta} ({Provincia})";
        }
    }

    class Contatto
    {
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public Indirizzo Indirizzo { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }

        // Costruttore completo
        public Contatto(string nome, string cognome, Indirizzo indirizzo, string telefono, string email)
        {
            Nome = nome;
            Cognome = cognome;
            Indirizzo = indirizzo;
            Telefono = telefono;
            Email = email;
        }

        // Costruttore parziale
        public Contatto(string nome, string cognome)
        {
            Nome = nome;
            Cognome = cognome;
            Indirizzo = new Indirizzo();
            Telefono = "X";
            Email = "X";
        }

        public string SchedaCompleta()
        {
            return $"{Nome} {Cognome} - {Indirizzo} Tel. {Telefono} - email: {Email}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Indirizzo indirizzo1 = new Indirizzo("Trento 28", "10100", "Torino", "TO");
            Contatto contatto1 = new Contatto("Mario", "Rossi", indirizzo1, "011-4329512", "RossiM@tuttoweb.it");

            Contatto contatto2 = new Contatto("Giulia", "Bianchi");

            Console.WriteLine("Scheda contatto 1:");
            Console.WriteLine(contatto1.SchedaCompleta());

            Console.WriteLine("\nScheda contatto 2:");
            Console.WriteLine(contatto2.SchedaCompleta());
        }
    }
}
