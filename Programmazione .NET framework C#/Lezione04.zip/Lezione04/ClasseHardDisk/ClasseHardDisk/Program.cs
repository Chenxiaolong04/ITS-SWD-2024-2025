﻿namespace ClasseHardDisk
{
    class HardDisk
    {
        public string Marca { get; set; }
        public int VelocitaRTM { get; set; }      
        public int TempoAccessoMS { get; set; }   
        public int CapacitaGB { get; set; }       

        public int CalcolaPunteggio()
        {
            return VelocitaRTM - (TempoAccessoMS * 200) + (CapacitaGB * 500);
        }

        public void Stampa()
        {
            Console.WriteLine($"Marca: {Marca}");
            Console.WriteLine($"Velocità: {VelocitaRTM} RTM");
            Console.WriteLine($"Tempo di accesso: {TempoAccessoMS} ms");
            Console.WriteLine($"Capacità: {CapacitaGB} GB");
            Console.WriteLine($"Punteggio: {CalcolaPunteggio()}\n");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            HardDisk h1 = new HardDisk();
            h1.Marca = "Seagate";
            h1.VelocitaRTM = 7200;
            h1.TempoAccessoMS = 9;
            h1.CapacitaGB = 1000;

            HardDisk h2 = new HardDisk();
            h2.Marca = "Western Digital";
            h2.VelocitaRTM = 5400;
            h2.TempoAccessoMS = 12;
            h2.CapacitaGB = 2000;

            HardDisk h3 = new HardDisk();
            h3.Marca = "Samsung";
            h3.VelocitaRTM = 10000;
            h3.TempoAccessoMS = 6;
            h3.CapacitaGB = 500;

            HardDisk h4 = new HardDisk();
            h4.Marca = "Toshiba";
            h4.VelocitaRTM = 7200;
            h4.TempoAccessoMS = 10;
            h4.CapacitaGB = 1500;

            HardDisk h5 = new HardDisk();
            h5.Marca = "Hitachi";
            h5.VelocitaRTM = 5900;
            h5.TempoAccessoMS = 11;
            h5.CapacitaGB = 750;

            Console.WriteLine("Valutazione Hard Disk:\n");
            h1.Stampa();
            h2.Stampa();
            h3.Stampa();
            h4.Stampa();
            h5.Stampa();
        }
    }
}
