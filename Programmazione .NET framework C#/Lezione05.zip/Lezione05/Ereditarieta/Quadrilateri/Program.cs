﻿namespace Quadrilateri
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ereditarietà");

            Quadrilatero q1 = new Quadrilatero(1.25, 1.5, 4, 2.75);
            Console.WriteLine(q1);

            var r1 = new Rettangolo(1.75,2.25);
            Console.WriteLine(r1);

            var q2 = new Quadrato(1.5);
            Console.WriteLine(q2);
        }
    }
}
