﻿namespace Veicoli
{
    internal enum Carburante
    {
        BENZINA,DIESEL,GPL,METANO
    }
}