﻿namespace Veicoli
{
    internal enum TipoCambio
    {
        MANUALE,AUTOMATICO
    }
}