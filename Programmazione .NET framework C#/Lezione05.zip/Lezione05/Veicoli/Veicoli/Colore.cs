﻿namespace Veicoli
{
    internal enum Colore
    {
        BIANCO,VERDE,BLU,NERO
    }
}