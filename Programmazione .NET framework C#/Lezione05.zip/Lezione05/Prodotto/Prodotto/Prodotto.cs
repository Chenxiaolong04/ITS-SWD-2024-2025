﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prodotto
{
    internal class Prodotto
    {
        public int Codice {  get; set; }
        public string? 
    }
}
