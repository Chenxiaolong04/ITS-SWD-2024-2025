﻿namespace ClassePersona
{
    internal enum Sesso
    {
        Altro,F,M
    }
}