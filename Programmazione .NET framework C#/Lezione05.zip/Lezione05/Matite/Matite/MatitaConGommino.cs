﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matite
{
    internal class MatitaConGommino:Matita
    {
        public int cancellatureRimanenti { get; private set; } = 10;

        public int cancellazione()
        {
            if(cancellatureRimanenti < 0)
                cancellatureRimanenti = 0;
            else
                cancellatureRimanenti--;
            return cancellatureRimanenti;
        }
        public override string ToString()
        {
            return base.ToString() + $", Cancellature rimaste: {cancellatureRimanenti}";
        }
    }
}
