﻿namespace Matite
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MatitaConGommino m1 = new MatitaConGommino();
            m1.Marca = "Faber-Castell";
            m1.Modello = "HB";
            m1.Tempera();
            m1.Tempera();
            m1.Tempera();
            Console.WriteLine(m1);

            MatitaConGommino m2 = new MatitaConGommino();
            m2.Marca = "Staedtler";
            m2.Modello = "Norica";
            m2.cancellazione();
            Console.WriteLine(m2);
        }
    }
}
