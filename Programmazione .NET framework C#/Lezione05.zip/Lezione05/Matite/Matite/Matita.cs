﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matite
{
    internal class Matita
    {
        //proprieta public
        public string Marca { get; set;}
        public string Modello { get; set; }
        public double Lunghezza { get; set; } = 20;

        public override string ToString()
        {
            return $"Matita Marca: {Marca}, Modello: {Modello}, Lunghezza: {Lunghezza} cm";
        }
        public void Tempera()
        {
            if (Lunghezza > 0.5)
                Lunghezza -= 0.5;
            else
                Lunghezza = 0;
        }

    }
}
